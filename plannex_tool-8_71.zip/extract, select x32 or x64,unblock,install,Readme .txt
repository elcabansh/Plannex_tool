Kindly only run the file that aligns with your operating system
Make sure to extract the files from zip file 

Key issues And Solution :			
1- Save as add in issue +1004	https://youtu.be/ZVnqY8dXbwo		
2- Error 1004 for WBS coloring	https://plannexcg.com/error-1004/		
2-The add-in has been Blocked	https://plannexcg.com/remove-excel-block/ 		

