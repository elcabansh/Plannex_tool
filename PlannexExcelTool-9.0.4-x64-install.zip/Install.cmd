@echo off
set "PLANNEX_INSTALLER=%~f0"
powershell.exe -NoLogo -NoProfile -Command "$raw=Get-Content -LiteralPath $env:PLANNEX_INSTALLER -Raw; & ([scriptblock]::Create(($raw -split '(?m)^# POWERSHELL START\r?$',2)[1]))"
pause
exit /b
# POWERSHELL START
$ErrorActionPreference = 'Stop'
try {
    $source = Split-Path -Parent $env:PLANNEX_INSTALLER
    $is64 = Test-Path -LiteralPath (Join-Path $source 'PlannexExcelTool64.xll')
    $xllName = if ($is64) { 'PlannexExcelTool64.xll' } else { 'PlannexExcelTool.xll' }
    $runtimeFiles = @($xllName,'PlannexExcelTool.AddIn.dll')
    $hostFiles = @('ExcelDna.ManagedHost.dll','ExcelDna.Loader.dll','ExcelDna.Integration.dll')
    $presentHostFiles = @($hostFiles | Where-Object { Test-Path -LiteralPath (Join-Path $source $_) })
    if ($presentHostFiles.Count -gt 0 -and $presentHostFiles -notcontains 'ExcelDna.ManagedHost.dll') {
        throw 'ExcelDna.ManagedHost.dll is required when client-compatible host files are included. Extract the entire ZIP again.'
    }
    $runtimeFiles += $presentHostFiles
    foreach ($name in $runtimeFiles) {
        if (-not (Test-Path -LiteralPath (Join-Path $source $name))) { throw "Missing $name. Extract the entire ZIP first." }
    }
    if (Get-Process EXCEL -ErrorAction SilentlyContinue) { throw 'Save your work and close ALL Excel windows, then double-click Install.cmd again. No files or settings were changed.' }
    $excelPath = $null
    foreach ($key in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\excel.exe','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\excel.exe')) {
        if (Test-Path $key) { $excelPath = (Get-Item $key).GetValue(''); if ($excelPath) { break } }
    }
    if (-not $excelPath -or -not (Test-Path -LiteralPath $excelPath)) { throw 'Microsoft Excel was not found. Install this package through Excel Add-ins manually.' }
    $stream = [IO.File]::OpenRead($excelPath)
    $reader = New-Object IO.BinaryReader($stream)
    try { $stream.Position=0x3c; $pe=$reader.ReadInt32(); $stream.Position=$pe+4; $machine=$reader.ReadUInt16() } finally { $reader.Dispose() }
    $expectedMachine = if ($is64) { 0x8664 } else { 0x14c }
    if ($machine -ne $expectedMachine) { throw 'This package does not match the Excel bitness. Download the matching x86 or x64 package; no changes were made.' }
    $programFilesForRuntime = if ($is64) { if ($env:ProgramW6432) { $env:ProgramW6432 } else { $env:ProgramFiles } } else { if (${env:ProgramFiles(x86)}) { ${env:ProgramFiles(x86)} } else { $env:ProgramFiles } }
    $runtime = Join-Path $programFilesForRuntime 'dotnet\shared\Microsoft.WindowsDesktop.App'
    if (-not (Get-ChildItem -LiteralPath $runtime -Directory -ErrorAction SilentlyContinue | Where-Object Name -Like '8.*')) { throw 'The matching .NET 8 Desktop Runtime is required. Install it, then run this installer again.' }
    $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($excelPath).FileMajorPart.ToString() + '.0'
    $options = "HKCU:\Software\Microsoft\Office\$version\Excel\Options"
    $destination = Join-Path $env:LOCALAPPDATA 'Plannex Excel Tool\app'
    $command = '/R "' + (Join-Path $destination $xllName) + '"'
    $legacyPattern = '^/R "' + [regex]::Escape((Join-Path $env:LOCALAPPDATA 'Plannex Excel Tool')) + '\\8\.99-two-file-[^\\"]+\\PlannexExcelTool(64)?\.xll"$'
    $migrate = @()
    $olderPlannex = $false
    # Never remove another add-in's registration; an older enabled Plannex add-in is suggested after the install (R56).
    if (Test-Path $options) {
        $oldOptions = Get-Item $options
        foreach ($entry in @($oldOptions.GetValueNames() | Where-Object { $_ -match '^OPEN\d*$' })) {
            $value = [string]$oldOptions.GetValue($entry)
            if ($value -match $legacyPattern) { $migrate += $entry; continue }
            if ($value -ne $command -and $value -match '(?i)plannex[^"\\/]*\.(xll|xlam|xlsm)') {
                $olderPlannex = $true
            }
        }
    }
    # No elevation, Trust Center changes, downloads, or termination of Excel.
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    foreach ($name in $runtimeFiles) {
        Copy-Item -LiteralPath (Join-Path $source $name) -Destination $destination -Force
    }
    # Explorer can propagate the Internet security zone from a downloaded ZIP.
    # Remove that marker only from the two signed Plannex runtime files we copied.
    foreach ($name in $runtimeFiles) {
        Unblock-File -LiteralPath (Join-Path $destination $name) -ErrorAction Stop
    }
    # Reinstall is the repair route; invalidate any journal from an interrupted older package.
    $journal = Join-Path $destination 'update-journal.json'
    if (Test-Path -LiteralPath $journal) { Remove-Item -LiteralPath $journal -Force }

    # Trust only this stable local installation folder. This avoids changing
    # Excel's global Protected View, macro, or add-in security settings.
    $trustedLocations = "HKCU:\Software\Microsoft\Office\$version\Excel\Security\Trusted Locations"
    $trustedLocation = Join-Path $trustedLocations 'PlannexExcelTool'
    New-Item -Path $trustedLocation -Force | Out-Null
    New-ItemProperty -Path $trustedLocation -Name 'Path' -Value ($destination.TrimEnd('\') + '\') -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $trustedLocation -Name 'AllowSubfolders' -Value 0 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $trustedLocation -Name 'Description' -Value 'Plannex Excel Tool' -PropertyType String -Force | Out-Null
    New-Item -Path $options -Force | Out-Null
    $key = Get-Item $options
    $registeredStable = @($key.GetValueNames() | Where-Object { $_ -match '^OPEN\d*$' -and [string]$key.GetValue($_) -eq $command })
    foreach ($entry in $migrate) {
        # Reuse one known Plannex slot, or retain the already registered stable slot.
        # Remove only duplicate known legacy Plannex entries, never another add-in.
        if ($registeredStable.Count -eq 0) {
            New-ItemProperty -Path $options -Name $entry -Value $command -PropertyType String -Force | Out-Null
            $registeredStable = @($entry)
        } else { Remove-ItemProperty -Path $options -Name $entry }
    }
    $openNames = @($key.GetValueNames() | Where-Object { $_ -match '^OPEN\d*$' })
    $existing = @($openNames | Where-Object { [string]$key.GetValue($_) -eq $command })
    if ($existing.Count -eq 0) {
        $name = 'OPEN'; $index = 0
        while ($openNames -contains $name) { $index++; $name = 'OPEN' + $index }
        New-ItemProperty -Path $options -Name $name -Value $command -PropertyType String | Out-Null
    }
    $trustCheck = Get-ItemProperty -Path $trustedLocation -Name Path,AllowSubfolders -ErrorAction Stop
    if ($trustCheck.Path -ne ($destination.TrimEnd('\') + '\') -or $trustCheck.AllowSubfolders -ne 0) {
        throw 'Excel Trusted Location registration could not be verified.'
    }
    Write-Host 'Installed Plannex Excel Tool successfully.' -ForegroundColor Green
    Write-Host "Location: $destination"
    Write-Host 'Open Excel to use it.'
    if ($olderPlannex) {
        Write-Host 'Recommended: the older Plannex add-in (for example Plannex 8.99) is still turned on. In Excel go to File > Options > Add-ins, choose Excel Add-ins, click Go, untick the old Plannex version and restart Excel.' -ForegroundColor Yellow
    }
    Write-Host 'The signed XLL and DLL were unblocked and the exact installation folder was added as an Excel Trusted Location.'
    if ($presentHostFiles -contains 'ExcelDna.ManagedHost.dll') {
        Write-Host 'The client-compatible Excel-DNA managed host was installed beside the XLL to avoid temporary managed-host loading.'
    }
    Write-Host 'Organizational security policies can still override user Trusted Locations.'
} catch {
    Write-Host ('Installation stopped: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
